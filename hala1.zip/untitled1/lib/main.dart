import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home:Scaffold(
          appBar: AppBar(
            title: Text("Student"),

          ),
          body: Display()

      ),

      /* routes: <String, WidgetBuilder>{
        '/c': (BuildContext context) => SecondPage(),
      },*/

    );
  }
}

class Display extends StatefulWidget{
  @override
  _ListDisplayState createState() {
    return _ListDisplayState();
  }

}

class _ListDisplayState extends State<Display>{

  List<Student> students = [
    Student("Hala",'10-5050', "anonymous.jpg", false),
    Student("Marwan", '11-6060',"anonymous.jpg", false),
    Student("Jana", '12-7070', "anonymous.jpg", false),
    Student("Mohmaad", '13-8080',"anonymous.jpg", false),

  ];

  List<Student> favoriteStd = [];

  void _setMovieAsFavorite(int index){
    setState(() {
      this.students[index].IsFavorite = !this.students[index].IsFavorite;
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: students.length,
      itemBuilder: (BuildContext context, int index) {
        return  FirstPage(
          std: this.students[index],
          setFavorite: () {
            _setMovieAsFavorite(index);
          },
        );

      },
    );

  }
}

class Student{
  String Name;
  String Id;
  String Image;
  bool IsFavorite;

  Student(this.Name, this.Id, this.Image, this.IsFavorite);
}

class FirstPage extends StatelessWidget {

  final Student std;

  final VoidCallback setFavorite;

  FirstPage(
      {required this.std,required this.setFavorite});

  @override
  Widget build(BuildContext context) {
    return Container(

      padding: EdgeInsets.all(4),
      height: 120,
      child: Card(
        child: Row(
          children: [
            Image.asset('assets/images/' + this.std.Image),
            Expanded(
                child: Container(
                  padding: EdgeInsets.all(5),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(this.std.Name, style: TextStyle(fontSize: 18),),
                      Text(this.std.Id, style: TextStyle(fontSize: 18),),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          IconButton(
                              icon: Icon(
                                this.std.IsFavorite ? Icons.add : Icons
                                    .star_border,
                              ),
                              onPressed: setFavorite),

                        ],
                      )

                    ],
                  ),
                )
            ),
            TextButton(
                child: Text('Press to next page'),
                onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => SecondPage(std)));
                }),
          ],
        ),

      ),

    );


  }
}
class SecondPage extends StatelessWidget {
  final Student st;
  SecondPage(@required this.st);
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
            appBar: AppBar(title: MaterialButton(
              child: Text('Back'),
              onPressed: (){
                Navigator.pop(context);
              },
            ),),

            body: Center(
              child: Row(
                children: [
                  if (st.IsFavorite) Text(st.Name) else const Text('None'),
                ],
              ),

            )

        )
    );

  }

}